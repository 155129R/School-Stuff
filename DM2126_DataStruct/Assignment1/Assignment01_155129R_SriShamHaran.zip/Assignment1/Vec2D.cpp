#include "Vec2D.h"

Vec2D::Vec2D()
{

}

Vec2D::Vec2D(double xPos, double yPos)
:x(xPos), y(yPos)
{

}